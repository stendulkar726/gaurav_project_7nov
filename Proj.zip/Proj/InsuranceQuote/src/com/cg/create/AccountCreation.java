package com.cg.create;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.cg.beans.Accounts;
import com.cg.exception.UserCustomException;
import com.cg.service.InsuranceService;
import com.cg.service.InsuranceServiceImpl;
import com.cg.service.ValidAcc;

public class AccountCreation {

	Scanner scanner=null;
	int accountNumber=0;
	InsuranceService service=new InsuranceServiceImpl();
	public int createAccount( String userName){
		//Creating the null value elements
		String insuredName = "";
		String insuredStreet = "";
		String insuredCity = "";
		String insuredState = "";
		int insuredZip = 0;
		String businessSeg = "";
		ValidAcc a = new ValidAcc();
		boolean zipFlag = false;
		scanner=new Scanner(System.in);
		//---------------------------------------------------
		//Getting Input
		boolean ins1=false;
		
		System.out.println("Enter insured Name: ");
		do {
		insuredName = scanner.nextLine();
		ins1 =a.vali(insuredName);
//		System.out.println(ins1);
		}while(!ins1);
		String  insuredName1 = insuredName.toLowerCase(); //----------------------
		
		
		System.out.println("Enter insured Street: ");
		do {
		insuredStreet = scanner.nextLine();
		ins1 =a.vali(insuredStreet);
//		System.out.println(ins1);
		}while(!ins1);
		String insuredStreet1 =insuredStreet.toLowerCase(); //--------------------
		
		
		System.out.println("Enter insured City: ");
		do {
		insuredCity = scanner.nextLine();
		ins1 =a.vali(insuredCity);
//		System.out.println(ins1);
		}while(!ins1);
		String insuredCity1 = insuredCity.toLowerCase(); //-----------------------

		
		System.out.println("Enter insured State: ");
		do {
		insuredState = scanner.nextLine();
		ins1 =a.vali(insuredState);
//		System.out.println(ins1);
		}while(!ins1);
		String insuredState1 = insuredState.toLowerCase(); //---------------------

		do {
			System.out.println("Enter insured Zip: ");
			scanner = new Scanner(System.in);
			try {

				insuredZip = scanner.nextInt();
				zipFlag = true;

			} catch (InputMismatchException e) {

				System.err.println("Enter digits only");
				zipFlag = false;
			}

		} while (!zipFlag);
		scanner.nextLine();

		
		System.out.println("Enter business Segment: ");
		do {
		businessSeg = scanner.nextLine();
		ins1 =a.vali(businessSeg);
		System.out.println(ins1);
		}while(!ins1);
		String businessSeg1 = businessSeg.toLowerCase();
		
		
		Accounts accounts=new Accounts(insuredName1, insuredStreet1, insuredCity1, insuredState1, insuredZip, businessSeg1,userName);
		boolean validFlag=false;
		try {
			validFlag = service.validFields(accounts);
		} catch (UserCustomException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		if(validFlag==true)
		{
			try {
					accountNumber=service.createAccount(accounts);
			
			}catch (UserCustomException e) {
				System.err.println(e.getMessage());
			}
		}
		return accountNumber;
		
	}
	
}
