package com.cg.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public class ValidAcc {
	boolean ai = false;
	public boolean vali(String insert) {
		String nameRegEx= "[A-Za-z]*$";
		if(! Pattern.matches(nameRegEx, insert)) {
			System.out.println("Invalid input");
			ai=false;
		}else {
		ai=true;
		};
		System.out.println(ai);
		return ai;
	 }

}
