package com.cg.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import com.cg.exception.UserCustomException;


public class DbConfig {

	private static Connection connection = null;

	public static Connection getConnection() throws UserCustomException {

		try {
			String driver ="oracle.jdbc.OracleDriver";
			String url ="jdbc:oracle:thin:@localhost:1521:XE";
			String username = "ANINDIT";
			String password = "ANINDIT1";
			Class.forName(driver);
			connection = DriverManager.getConnection(url, username, password);

		} catch (ClassNotFoundException e) {
			//throw new UserCustomException("class not loaded");
			e.printStackTrace();
		} catch (SQLException e) {
			throw new UserCustomException("connection issue");
		}

		return connection;
	}
}

